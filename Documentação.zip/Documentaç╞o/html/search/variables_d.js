var searchData=
[
  ['ret_5fwords_1078',['ret_words',['../class_frame.html#ab57f7311279aec5dbc4466bdbe823fd7',1,'Frame']]]
];
