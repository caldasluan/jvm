var searchData=
[
  ['wide_951',['wide',['../instructions_8cpp.html#acef8d9346c3e0f797be9d7193bfa9035',1,'wide(Frame &amp;frame):&#160;instructions.cpp'],['../instructions_8h.html#a65a75773114a18b66edf5249a625937e',1,'wide(Frame &amp;):&#160;instructions.cpp']]]
];
