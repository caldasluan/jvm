var searchData=
[
  ['operand_5fstack_1072',['operand_stack',['../class_frame.html#a556dae40c22be59fa54c34f72ce92495',1,'Frame']]],
  ['operands_1073',['operands',['../class_instruction.html#a7a4845403c01a5b0d4af509c2421557a',1,'Instruction']]],
  ['outer_5fclass_5finfo_5findex_1074',['outer_class_info_index',['../structclass__struct.html#aaeef7f8af56b0abcbc2295733e6c6682',1,'class_struct']]]
];
