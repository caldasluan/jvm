var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvw~",
  1: "abcdefilmr",
  2: "acdefimr",
  3: "abcdefghijlmnoprstuw~",
  4: "abcdefhilmnoprstv",
  5: "e",
  6: "ao"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de tipos",
  6: "Macros"
};

