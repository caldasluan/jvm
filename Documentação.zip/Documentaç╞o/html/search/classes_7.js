var searchData=
[
  ['line_5fnumber_593',['line_number',['../structline__number.html',1,'']]],
  ['local_5fvariable_594',['local_variable',['../structlocal__variable.html',1,'']]],
  ['local_5fvariable_5ftype_595',['local_variable_type',['../structlocal__variable__type.html',1,'']]]
];
