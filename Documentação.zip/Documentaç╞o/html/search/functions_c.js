var searchData=
[
  ['newarray_919',['newarray',['../instructions_8cpp.html#aed149e05e0ba78dbe1720d6d82db9e8e',1,'newarray(Frame &amp;frame):&#160;instructions.cpp'],['../instructions_8h.html#a676d9a9728301bfc15e6f944ec752a13',1,'newarray(Frame &amp;):&#160;instructions.cpp']]],
  ['nop_920',['nop',['../instructions_8cpp.html#a9b3c51db16694a42e308ab618dc390ba',1,'nop(Frame &amp;frame):&#160;instructions.cpp'],['../instructions_8h.html#aebcc53d3d74167f5f515c520e1830bbe',1,'nop(Frame &amp;):&#160;instructions.cpp']]]
];
