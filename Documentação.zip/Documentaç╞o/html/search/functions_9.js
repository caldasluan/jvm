var searchData=
[
  ['jsr_876',['jsr',['../instructions_8cpp.html#a478f588b80b2bb98479737829c710957',1,'jsr(Frame &amp;frame):&#160;instructions.cpp'],['../instructions_8h.html#a1c3d94b7fc7d1493ad5a97fc56d3d691',1,'jsr(Frame &amp;):&#160;instructions.cpp']]],
  ['jsr_5fw_877',['jsr_w',['../instructions_8cpp.html#a1673fec323111624677216b81adb39f4',1,'jsr_w(Frame &amp;frame):&#160;instructions.cpp'],['../instructions_8h.html#aa1291b414b043eae186548c06ab635bb',1,'jsr_w(Frame &amp;):&#160;instructions.cpp']]]
];
